import React, {createContext} from "react";

const FilterContext = createContext(undefined);
export default FilterContext